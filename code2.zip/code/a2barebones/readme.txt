script_regression.py runs all algorithms in default. You can comment out algorithms in regressionalgs dict to run fewer algorithms.
Std error implemented. Also implement method to get error of training set.
regressionalgorithms.py implements all algorithms for assignment and some plot functions. You can uncomment the relavent plot code to check the result.